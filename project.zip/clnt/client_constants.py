"""
Matan Zamir

client's constants
"""

PORT = 13003
IP = "127.0.0.1"
EXIT = 1
