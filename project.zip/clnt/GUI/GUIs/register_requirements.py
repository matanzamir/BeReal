"""
Matan Zamir

register requirements
"""

ENTER_ALL = "you need to enter all of the info"
UNDER_16 = "username must be under 16 characters"
SPECIAL = "username and password can't contain " \
          "any special character and or spacer"
ABOVE_6 = 'password must be above 6 characters'
MATCH = 'passwords does not match'
