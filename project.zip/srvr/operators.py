"""
Matan Zamir

operators constants
"""

PARAMS = '&'
EOT = '*'
SAP = '+'
SPLIT = ':'

FORBIDDEN = ['&', '*', '+', ' ', ':']
