"""
Matan Zamir

constants for database
"""

ARR_POS_0 = 0
LEN_OF_0 = 0
